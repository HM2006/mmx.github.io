<?php
$authcode='FUCK B.JACK';
$distid='c';
/**
资源之咖首发
By百晓
资源之咖
**/
?>