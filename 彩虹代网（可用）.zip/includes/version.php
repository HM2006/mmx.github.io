<?php
/**
资源之咖首发
**/
define('VERSION', '2005');
define('DB_VERSION', '2001');
?>